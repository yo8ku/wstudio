# @note-studio/plugin

WStudio public plugin SDK package.

This package contains the TypeScript declarations and runtime entry points used
by third-party plugin authors when building plugins for WStudio.

## What It Provides

- plugin base classes
- workspace, vault, editor, markdown, and UI contracts
- lifecycle and manifest types
- declarative resource contributions such as `contributes.iconThemes`
- runtime bridge symbols used by the host

## Install

```bash
npm install @note-studio/plugin
```

## Entry Points

- `@note-studio/plugin`
- `@note-studio/plugin/internal/runtime`

## Testing Docs

- [API inventory](./docs/API_INVENTORY.md)
- [API test matrix](./docs/API_TEST_MATRIX.md)
- [Canvas host baseline](./docs/CANVAS_PLUGIN_HOST_BASELINE.md)
- [Canvas host todo](./docs/CANVAS_HOST_TODO.md)
- [Canvas file schema](./docs/CANVAS_FILE_SCHEMA.md)

## Resource-Only Plugins

WStudio now supports resource-only plugins for file icon themes.

- Declare themes under `contributes.iconThemes` in `manifest.json`
- Point each contribution `path` to an `icon-theme.json` file inside the plugin directory
- `main.js` is optional when the plugin only contributes icon themes
- For development, prefer a `src -> dist` layout so the host reads only built assets

## Plugin Logos

WStudio supports plugin logos for installed-plugin surfaces through the plugin manifest.

- Declare `icon` in `manifest.json`, for example `assets/logo.svg`
- Keep the icon asset inside the plugin directory
- If `icon` is omitted, the host also checks `assets/logo.svg` as the default logo candidate
- Plugin logo assets are loaded through the host `wstudio-extension://` protocol instead of direct `file://` URLs
