# @note-studio/plugin

WStudio public plugin SDK package.

This package contains the TypeScript declarations and runtime entry points used
by third-party plugin authors when building plugins for WStudio.

## What It Provides

- plugin base classes
- workspace, vault, editor, markdown, and UI contracts
- lifecycle and manifest types
- runtime bridge symbols used by the host

## Install

```bash
npm install @note-studio/plugin
```

## Entry Points

- `@note-studio/plugin`
- `@note-studio/plugin/internal/runtime`

## Testing Docs

- [API inventory](./docs/API_INVENTORY.md)
- [API test matrix](./docs/API_TEST_MATRIX.md)
- [Canvas host baseline](./docs/CANVAS_PLUGIN_HOST_BASELINE.md)
- [Canvas host todo](./docs/CANVAS_HOST_TODO.md)
- [Canvas file schema](./docs/CANVAS_FILE_SCHEMA.md)
